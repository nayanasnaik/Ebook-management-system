# lms
Basic Library managment System Build on Spring Boot

for more details about project refer 

https://letslearnjavanow.wordpress.com/2018/04/16/library-management-system-using-angular-spring-boot-spring-curd-rest-controller-mysql/

Features Developed:

Fetching all Books
Making a borrow request
Make a cancellation request
Make a add book request

Features Under Development:

Authenication User, Books
Email support
Barcode genration for each Book


Download this project
Import in STS
Run it as Spring Boot app
URL
http://localhost:8080/search
